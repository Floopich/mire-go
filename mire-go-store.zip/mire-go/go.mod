module github.com/floopich/mire-go

go 1.24

require github.com/mattn/go-sqlite3 v1.14.52
