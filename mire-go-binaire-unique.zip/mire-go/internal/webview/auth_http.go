package webview

import (
	"net"
	"net/http"
	"strings"
	"time"

	"github.com/floopich/mire-go/internal/auth"
)

const sessionCookie = "mire_session"

// requireAuth protege une route.
//
// Tout est ferme sauf la connexion : la page de reglages laisse changer
// l'adresse et le mot de passe du modem, et les relevés eux-memes disent
// quand la maison est vide.
func (s *Server) requireAuth(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		cookie, err := r.Cookie(sessionCookie)
		if err != nil || s.sessions.Valid(r.Context(), cookie.Value) != nil {
			http.Redirect(w, r, s.prefix+"/connexion", http.StatusSeeOther)
			return
		}
		next(w, r)
	}
}

func (s *Server) handleLoginForm(w http.ResponseWriter, r *http.Request) {
	// Deja connecte : inutile de redemander.
	if cookie, err := r.Cookie(sessionCookie); err == nil &&
		s.sessions.Valid(r.Context(), cookie.Value) == nil {
		http.Redirect(w, r, s.prefix+"/", http.StatusSeeOther)
		return
	}
	s.renderLogin(w, loginData{
		InitialPending: auth.InitialPasswordPending(s.dataDir),
	})
}

func (s *Server) handleLogin(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	key := clientKey(r)

	// Le SameSite=Strict du cookie bloque deja la soumission depuis un autre
	// site ; on refuse en plus une origine etrangere, qui n'a aucune raison
	// d'exister sur un formulaire local.
	if !sameOrigin(r) {
		http.Error(w, "origine refusee", http.StatusForbidden)
		return
	}
	if wait := s.limiter.Wait(key); wait > 0 {
		s.renderLogin(w, loginData{
			Err:            "Trop de tentatives. Reessayez dans " + humanDelay(wait) + ".",
			InitialPending: auth.InitialPasswordPending(s.dataDir),
		})
		return
	}
	if err := r.ParseForm(); err != nil {
		http.Error(w, "formulaire illisible", http.StatusBadRequest)
		return
	}

	ok, err := auth.Check(ctx, s.db, r.PostFormValue("mot_de_passe"))
	if err != nil || !ok {
		s.limiter.Fail(key)
		// Le message ne distingue pas "pas de mot de passe configure" de
		// "mauvais mot de passe" : la difference renseignerait un curieux.
		s.renderLogin(w, loginData{
			Err:            "Mot de passe incorrect.",
			InitialPending: auth.InitialPasswordPending(s.dataDir),
		})
		return
	}

	token, err := s.sessions.Create(ctx)
	if err != nil {
		http.Error(w, "session impossible", http.StatusInternalServerError)
		return
	}
	s.limiter.Succeed(key)
	http.SetCookie(w, &http.Cookie{
		Name:     sessionCookie,
		Value:    token,
		Path:     s.prefix + "/",
		HttpOnly: true,
		SameSite: http.SameSiteStrictMode,
		Secure:   r.TLS != nil,
		Expires:  time.Now().Add(auth.SessionLifetime),
	})
	http.Redirect(w, r, s.prefix+"/", http.StatusSeeOther)
}

func (s *Server) handleLogout(w http.ResponseWriter, r *http.Request) {
	if cookie, err := r.Cookie(sessionCookie); err == nil {
		_ = s.sessions.Revoke(r.Context(), cookie.Value)
	}
	http.SetCookie(w, &http.Cookie{
		Name: sessionCookie, Value: "", Path: s.prefix + "/",
		HttpOnly: true, MaxAge: -1,
	})
	http.Redirect(w, r, s.prefix+"/connexion", http.StatusSeeOther)
}

// clientKey identifie l'appelant pour le limiteur.
//
// On prend l'adresse de la connexion, pas un en-tete : X-Forwarded-For se
// falsifie, et une adresse falsifiee permettrait de contourner le limiteur en
// changeant d'identite a chaque essai.
func clientKey(r *http.Request) string {
	host, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		return r.RemoteAddr
	}
	return host
}

// sameOrigin verifie que la requete vient de cette instance.
func sameOrigin(r *http.Request) bool {
	origin := r.Header.Get("Origin")
	if origin == "" {
		// Pas d'Origin : requete non navigateur ou navigateur ancien. Le
		// Referer sert de repli, son absence n'est pas bloquante.
		ref := r.Header.Get("Referer")
		return ref == "" || strings.Contains(ref, r.Host)
	}
	return strings.HasSuffix(origin, "//"+r.Host) || strings.Contains(origin, r.Host)
}

func humanDelay(d time.Duration) string {
	if d < time.Minute {
		return d.Round(time.Second).String()
	}
	return d.Round(time.Minute).String()
}
