// Commande mire : collecte les releves DOCSIS et sert l'interface.
//
// Un seul processus, un seul port, un seul service a installer. La collecte
// tourne en tache de fond ; l'interface reste disponible meme quand le modem
// ne repond pas, puisque c'est precisement le moment ou l'on veut consulter
// l'historique.
package main

import (
	"context"
	"errors"
	"flag"
	"fmt"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"path/filepath"
	"strings"
	"sync"
	"syscall"
	"time"

	"github.com/floopich/mire-go/internal/auth"
	"github.com/floopich/mire-go/internal/collect"
	"github.com/floopich/mire-go/internal/modem"
	"github.com/floopich/mire-go/internal/operator"
	"github.com/floopich/mire-go/internal/store"
	"github.com/floopich/mire-go/internal/webview"
)

func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, "erreur :", err)
		os.Exit(1)
	}
}

func run() error {
	var (
		dataDir   = flag.String("donnees", ".", "dossier des donnees")
		addr      = flag.String("ecoute", "0.0.0.0:1340", "adresse d'ecoute")
		profileID = flag.String("profil", "voo", "profil d'operateur")
		modemURL  = flag.String("modem", "", "adresse du modem (defaut : celle du profil)")
		user      = flag.String("utilisateur", "voo", "identifiant du modem")
		interval  = flag.Duration("intervalle", 10*time.Minute, "delai entre deux releves")
		retention = flag.Int("retention", store.DefaultRetention.Days, "conservation en jours, 0 pour illimite")
		maxGB     = flag.Float64("taille-max", 5, "plafond de la base en Go, 0 pour illimite")
		verbose   = flag.Bool("verbeux", false, "journaliser chaque releve")
	)
	flag.Parse()

	level := slog.LevelInfo
	if *verbose {
		level = slog.LevelDebug
	}
	logger := slog.New(slog.NewTextHandler(os.Stderr, &slog.HandlerOptions{Level: level}))

	profile, err := operator.Load(*profileID)
	if err != nil {
		return err
	}
	if err := os.MkdirAll(*dataDir, 0o755); err != nil {
		return err
	}
	db, err := store.Open(filepath.Join(*dataDir, "mire.db"))
	if err != nil {
		return err
	}
	defer func() { _ = db.Close() }()

	ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer stop()

	// Avant toute route : sans mot de passe, l'interface n'authentifie rien.
	if err := auth.Bootstrap(ctx, db, *dataDir, logger); err != nil {
		return err
	}

	srv, err := webview.NewServer(db, profile, *dataDir)
	if err != nil {
		return err
	}

	var wg sync.WaitGroup
	// La collecte ne demarre que si un mot de passe de modem est fourni.
	// L'interface, elle, demarre toujours : c'est par elle qu'on configurera
	// le modem, et une page inaccessible tant que la collecte ne marche pas
	// rendrait l'installation impossible.
	if password := os.Getenv("MIRE_MODEM_PASSWORD"); password != "" {
		address := strings.TrimSpace(*modemURL)
		if address == "" {
			address = profile.DefaultModemURL
		}
		driver, err := modem.NewCGA4233(address, *user, password)
		if err != nil {
			return err
		}
		collector := collect.New(driver, db, collect.Options{
			Interval: *interval,
			Retention: store.Retention{
				Days:     *retention,
				MaxBytes: int64(*maxGB * float64(1<<30)),
			},
			Logger: logger,
		})
		wg.Add(1)
		go func() {
			defer wg.Done()
			logger.Info("collecte demarree", "modem", address, "intervalle", interval.String())
			if err := collector.Run(ctx); err != nil && !errors.Is(err, context.Canceled) {
				logger.Error("collecte arretee", "erreur", err)
			}
		}()
	} else {
		logger.Warn("collecte inactive : definir MIRE_MODEM_PASSWORD pour interroger le modem")
	}

	// Les sessions expirees sont purgees une fois par jour.
	sessions := auth.NewSessions(db)
	wg.Add(1)
	go func() {
		defer wg.Done()
		ticker := time.NewTicker(24 * time.Hour)
		defer ticker.Stop()
		for {
			select {
			case <-ctx.Done():
				return
			case <-ticker.C:
				if err := sessions.Prune(ctx); err != nil {
					logger.Warn("purge des sessions", "erreur", err)
				}
			}
		}
	}()

	server := &http.Server{
		Addr:              *addr,
		Handler:           srv.Routes(),
		ReadHeaderTimeout: 10 * time.Second,
	}
	go func() {
		<-ctx.Done()
		shutdown, cancel := context.WithTimeout(context.Background(), 10*time.Second)
		defer cancel()
		_ = server.Shutdown(shutdown)
	}()

	logger.Info("interface disponible", "adresse", "http://"+*addr, "profil", profile.ID)
	if err := server.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
		return err
	}
	wg.Wait()
	logger.Info("arrete")
	return nil
}
